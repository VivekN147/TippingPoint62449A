/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// TL                   encoder       A, B            
// TR                   encoder       C, D            
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
#include "cmath"
using namespace vex;

// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/
inertial inertial1 = inertial(PORT15);
motor FR = motor(PORT20, ratio6_1, false);
motor BR = motor(PORT19, ratio6_1, false);
motor FL = motor(PORT16, ratio6_1, true);
motor BL = motor(PORT17, ratio6_1, true);
motor arm = motor(PORT2, ratio36_1, false);
motor mogo = motor(PORT11, ratio36_1);
motor claw = motor(PORT1, ratio18_1, true);


controller Controller1 = vex::controller();

void armUp(float desired){
  arm.setRotation(0,degrees);
  arm.spinFor(desired,degrees);
  arm.stop(hold);
}

void armDown(float desired){
  arm.setRotation(0,degrees);
  arm.spinFor(-desired,degrees);
  arm.stop(hold);
}


void resetInertial(){
  inertial1.setRotation(0,degrees);
}


void turnRight(float desired){

    FR.spin(reverse,8,volt);
    BR.spin(reverse,8,volt);
    BL.spin(forward,8,volt);
    FL.spin(forward,8,volt);
  waitUntil((inertial1.rotation(degrees) >= desired));

  wait(50, msec);

    FR.spin(forward,3,volt);
    BR.spin(forward,3,volt);
    BL.spin(reverse,3,volt);
    FL.spin(reverse,3,volt);
  waitUntil((inertial1.rotation(degrees) <= desired+5));
    FR.stop(brake);
    BR.stop(brake);
    FL.stop(brake);
    BL.stop(brake);


}


void turnLeft(float desired){
    resetInertial();
    FR.spin(forward,8,volt);
    BR.spin(forward,8,volt);
    BL.spin(reverse,8,volt);
    FL.spin(reverse,8,volt);
  waitUntil((inertial1.rotation(degrees) <= -desired));

  wait(50, msec);

    FR.spin(reverse,3,volt);
    BR.spin(reverse,3,volt);
    BL.spin(forward,3,volt);
    FL.spin(forward,3,volt);
  waitUntil((inertial1.rotation(degrees) >= -desired-5));
    FR.stop(brake);
    BR.stop(brake);
    FL.stop(brake);
    BL.stop(brake);


}





void resetTrack (){
  TL.setPosition(0,degrees);
  TR.setPosition(0,degrees);
  vex::task::sleep(100);
}

  double pi = atan(1)*4;

void wheel (float placehold){
  FR.spin(forward, placehold*0.9 , voltageUnits::volt);
  BR.spin(forward, placehold*0.9 , voltageUnits::volt);
  FL.spin(forward, placehold , voltageUnits::volt);
  BL.spin(forward, placehold , voltageUnits::volt);
}
void wheelR (float placehold){
  FR.spin(forward, placehold*0.80 , voltageUnits::volt);
  BR.spin(forward, placehold*0.80 , voltageUnits::volt);
  FL.spin(forward, placehold , voltageUnits::volt);
  BL.spin(forward, placehold , voltageUnits::volt);
}
void wheelL (float placehold){
  FR.spin(forward, placehold , voltageUnits::volt);
  BR.spin(forward, placehold , voltageUnits::volt);
  FL.spin(forward, placehold*0.75 , voltageUnits::volt);
  BL.spin(forward, placehold*0.75 , voltageUnits::volt);
}

int moveFwd(float distan, int powerLvl){
  resetInertial();
  resetTrack();
  while (1){
  double averageDegree = (TL.position(degrees) + TR.position(degrees))/2;
  double distance1 = ((averageDegree/360)*2.75*pi);

    Brain.Screen.print(distance1);
    Brain.Screen.newLine();
    //uses inertial sensor rotation to keep straight
    //inertial rotation can go positive and negative
    if (inertial1.rotation()>1){
      FR.spin(forward, powerLvl , voltageUnits::volt);
      BR.spin(forward, powerLvl , voltageUnits::volt);
      FL.spin(forward, powerLvl*0.8 , voltageUnits::volt);
      BL.spin(forward, powerLvl*0.8 , voltageUnits::volt);
    }

    else if (inertial1.rotation()<-1){
      FR.spin(forward, powerLvl*0.8 , voltageUnits::volt);
      BR.spin(forward, powerLvl*0.8 , voltageUnits::volt);
      FL.spin(forward, powerLvl , voltageUnits::volt);
      BL.spin(forward, powerLvl , voltageUnits::volt);
    }

    else{
      FR.spin(forward,powerLvl,volt);
      BR.spin(forward,powerLvl,volt);
      BL.spin(forward,powerLvl,volt);
      FL.spin(forward,powerLvl,volt);
    }

    if (fabs(distan-distance1)<1){
    FR.stop(brake);
    BR.stop(brake);
    FL.stop(brake);
    BL.stop(brake);
    break;
    }


  }
return 1;


} 

int moveRev(float distan,int powerLvl){
  resetInertial();
  resetTrack();
  while (1){
  double averageDegree = (TL.position(degrees) + TR.position(degrees))/2;
  double distance1 = ((averageDegree/360)*2.75*pi);

    Brain.Screen.print(distance1);
    Brain.Screen.newLine();
    if (inertial1.rotation()<-1){
      FR.spin(reverse, powerLvl , voltageUnits::volt);
      BR.spin(reverse, powerLvl , voltageUnits::volt);
      FL.spin(reverse, powerLvl*0.8 , voltageUnits::volt);
      BL.spin(reverse, powerLvl*0.8 , voltageUnits::volt);
    }

    else if (inertial1.rotation()>1){
      FR.spin(reverse, powerLvl*0.80 , voltageUnits::volt);
      BR.spin(reverse, powerLvl*0.80 , voltageUnits::volt);
      FL.spin(reverse, powerLvl , voltageUnits::volt);
      BL.spin(reverse, powerLvl , voltageUnits::volt);
    }

    else{
      FR.spin(reverse,powerLvl,volt);
      BR.spin(reverse,powerLvl,volt);
      BL.spin(reverse,powerLvl,volt);
      FL.spin(reverse,powerLvl,volt);
    }

    if (fabs(fabs(distan)-fabs(distance1))<1){
    FR.stop(brake);
    BR.stop(brake);
    FL.stop(brake);
    BL.stop(brake);
    break;
    }


  }
return 1;


} 

void mogoUp(float desired){
  mogo.setRotation(0, degrees);
  mogo.setVelocity(80, pct);
  //multiplied by five to compensate for gear ratio
  mogo.rotateTo(desired*5, degrees);
}

int mogoDown(float desired){
  Brain.Screen.print(mogo.position(degrees));
  mogo.resetPosition();

  while(1){
  mogo.spin(reverse,10,volt);
  Brain.Screen.print(mogo.position(degrees));
  Brain.Screen.newLine();
  if (mogo.position(degrees)<=-desired){
  mogo.stop(hold);
  break;
  }
  }
  return 1;
}

int printTrackR(){
  while (1==1){
    Brain.Screen.newLine();
    Brain.Screen.print(TR.position(degrees));

  }

  return 1;
}

int clawDown(){
  claw.setRotation(0, degrees);
  claw.setVelocity(80, pct);
  claw.rotateTo(318, degrees);
  return 0;
}
void clawOpen(float desired){
  claw.setRotation(0, degrees);
  claw.setVelocity(80, pct);
  claw.rotateTo(-desired, degrees);
}
void (*clawPointer)(float) = &clawOpen;

void leftBoth(){
  task myThread = task(clawDown);
  moveRev(58, 10);
  moveRev(8,3);
  clawDown();
  moveRev(6,6);
  wait(500,msec);
  turnRight(45);
  mogoDown(125);
  wait(500,msec);
  resetTrack();
  moveFwd(20,10);
  mogoUp(30);
  turnRight(100);
  moveRev(30,10);
  mogoDown(27);
  moveRev(12,8);
  clawOpen(300);
  moveFwd(3,4);
  task::sleep(100);


  Brain.Screen.print(inertial1.rotation(degrees));
  Brain.Screen.print("finished");
}

void skills(){
  task myThread = task(clawDown);
  moveRev(45,10);
  wait(100,msec);
  moveRev(3,3);
  clawDown();
  turnLeft(33);
  mogoDown(615);
  moveFwd(15,10);
  wait(100,msec);
  mogoUp(30);
  armUp(100);
  moveRev(58,8);
  armUp(550);
  turnLeft(3);
  moveRev(10,8);
  turnRight(43);
  moveRev(10,6);
  armDown(110);
  clawOpen(330);
  armUp(100);
  moveFwd(2,8);
  turnLeft(90);
  mogoDown(100);
  armDown(620);
  moveRev(33,10);
  wait(100,msec);
  moveRev(4,3);
  clawDown();
  turnRight(50);
  task::sleep(100);


  Brain.Screen.print(inertial1.rotation(degrees));
  Brain.Screen.print("finished");
}

void WP(){
  mogoDown(615);
  moveFwd(18,6);
  wait(100,msec);
  mogoUp(30);
  moveRev(10,5);
  task::sleep(100);


  Brain.Screen.print(inertial1.rotation(degrees));
  Brain.Screen.print("finished");
}

void LeftSide(){
  task myThread = task(clawDown);
  moveRev(40, 10);
  wait(500,msec);
  moveRev(3,3);
  clawDown();
  moveFwd(30,10);
  clawOpen(300);
  moveFwd(4,6);
  task::sleep(100);


  Brain.Screen.print(inertial1.rotation(degrees));
  Brain.Screen.print("finished");
}

void center(){
  task myThread = task(clawDown);
  moveRev(50, 10);
  wait(500,msec);
  moveRev(3,3);
  clawDown();
  moveFwd(50,10);
  clawOpen(300);
  moveFwd(3,6);
  task::sleep(100);


  Brain.Screen.print(inertial1.rotation(degrees));
  Brain.Screen.print("finished");
}

void drawgrid(){
  Brain.Screen.setFillColor(yellow);
  Brain.Screen.drawRectangle(0,0,240,240);
  Brain.Screen.setPenColor(black);
  Brain.Screen.printAt(90, 120, true, "Skills");
  Brain.Screen.setFillColor(purple);
  Brain.Screen.drawRectangle(240,0,240,240);
  Brain.Screen.printAt(300, 120, true, "Competition");
}

void compgrid(){
  Brain.Screen.clearScreen();
  Brain.Screen.setFillColor(orange);
  Brain.Screen.drawRectangle(0, 0, 240, 120);
  Brain.Screen.printAt(80, 70, true, "LeftBoth");
  Brain.Screen.setFillColor(green);
  Brain.Screen.drawRectangle(240, 0, 240, 120);
  Brain.Screen.printAt(350, 70, true, "WP");
  Brain.Screen.setFillColor(cyan);
  Brain.Screen.drawRectangle(0, 120, 240, 120);
  Brain.Screen.printAt(80, 190, true, "LeftSide");
  Brain.Screen.setFillColor(red);
  Brain.Screen.drawRectangle(240,120, 240, 120);
  Brain.Screen.printAt(330, 190, true, "Center");
}

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  int screenstatus = 0;
  drawgrid();
  Brain.Screen.render(true, false);
  while(1){
    if(Brain.Screen.pressing()){
      int XPress = Brain.Screen.xPosition();
      int YPress = Brain.Screen.yPosition();
      if((XPress >= 0 && XPress <= 240) && (YPress >= 0 && YPress <= 240) && screenstatus == 0){
        wait(250, msec);
        screenstatus = 1;
        Brain.Screen.clearScreen();
        Brain.Screen.render();
        skills();
      }
      if((XPress >=240 && XPress <= 480) && (YPress >= 0 && YPress <= 240) && screenstatus == 0){
        wait(250, msec);
        screenstatus = 2;
        compgrid();
        Brain.Screen.render();
        }
        if(Brain.Screen.pressing()) {
        if((screenstatus == 2) && (XPress <= 240 && XPress >= 0) && (YPress <= 120 && YPress >= 0)){
          screenstatus = 3;
          Brain.Screen.clearScreen();
          Brain.Screen.render();
          leftBoth();
        } else if((screenstatus == 2) && (XPress <= 240 && XPress >= 0) && (YPress >= 120 && YPress <= 240)){
          screenstatus = 3;
          Brain.Screen.clearScreen();
          Brain.Screen.render();
          LeftSide();
        } else if ((screenstatus == 2) && (XPress >= 240 && XPress <= 480) && (YPress <= 120 && YPress >= 0)){
          screenstatus = 3;
          Brain.Screen.clearScreen();
          Brain.Screen.render();
          WP();
        } else if ((screenstatus ==2) && (XPress >= 240 && XPress <= 480) && (YPress >= 120 && YPress <= 240)){
          screenstatus = 3;
          Brain.Screen.clearScreen();
          Brain.Screen.render();
          center();
        }
      }
    }
  }
}
  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

/*
int resetArm(){
  while (!LimitSwitchG.pressing()){
    arm.spin(forward, 9, voltageUnits::volt);


  if (LimitSwitchG.pressing()){
    arm.stop(coast);
    arm.resetRotation();
    break;

  }

  }
  return 1;
  
}
*/


/*
int move(double value){
  resetTrack();
  while(1){
    double averagePosition = (TL.position(degrees) + TR.position(degrees))/2;
    double distance1 = ((averagePosition/360)*4*pi);
    double accelerate = (7/3)*(distance1)+2;
    int    constant=12;
    float  offset = value-12;
    double decelerate = -7/3*distance1+30+7/3*offset;
    double sum = accelerate + constant + decelerate;
    Brain.Screen.print(sum);
    Brain.Screen.newLine();
    
  if(value>=12){

      if((distance1<=3)){
      constant = 0;
      decelerate = 0;
      double sum = accelerate + constant + decelerate;
        if(TR.position(degrees) > TL.position(degrees)){
          wheelR(sum);
          }

        else if(TR.position(degrees) < TL.position(degrees)){
          wheelL(sum);
          }
        else {
          wheel(sum);
          }
      }

      else if((distance1>3 && distance1<value-3)){
      accelerate = 0;
      decelerate = 0;
      double sum = accelerate + constant + decelerate;
        if(TR.position(degrees) > TL.position(degrees)){
          wheelR(sum);
          }

        else if(TR.position(degrees) < TL.position(degrees)){
          wheelL(sum);
          }
        else {
          wheel(sum);
          }
      }

      else if (distance1>=value-3){
      accelerate = 0;
      constant = 0;
      double sum = accelerate + constant + decelerate;

        if(TR.position(degrees) > TL.position(degrees)){
          wheelR(sum);
          }

        else if(TR.position(degrees) < TL.position(degrees)){
          wheelL(sum);
          }
        else {
          wheel(sum);
          }

      }
    
      if(2 > (value - distance1) && (value - distance1) > -2){

      FL.stop(vex::brakeType::coast);
      BL.stop(vex::brakeType::coast);
      FR.stop(vex::brakeType::coast);
      BR.stop(vex::brakeType::coast);
      break;
      }
      }


  }
    vex::task::sleep(20);
  
  
  return 1;
}
*/

void autonomous(void) {
  //starts on left side of field and grabs two neutral mobile goals.
  // threads allow a function without arguments to run simultaneously with other functions.
  task myThread = task(clawDown);
  moveRev(43, 10);
  wait(500,msec);
  moveRev(3,3);
  clawDown();
  moveFwd(20,10);
  clawOpen(300);
  moveFwd(14,8);
  turnLeft(25);
  moveRev(48, 10);
  wait(500,msec);
  moveRev(3,3);
  clawDown();
  moveFwd(28,10);
  clawOpen(300);
  moveFwd(3,3);
  task::sleep(100);

  //leftovers from troubleshooting
  Brain.Screen.print(inertial1.rotation(degrees));
  Brain.Screen.print("finished");


}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  // User control code here, inside the loop
  while (1) {
  BL.spin(fwd, 0.8*0.12*(Controller1.Axis3.value()+Controller1.Axis1.value()) , volt);
  FL.spin(fwd, 0.8*0.12*(Controller1.Axis3.value()+Controller1.Axis1.value()) , volt);
  BR.spin(fwd, 0.7*0.12*(Controller1.Axis3.value()-Controller1.Axis1.value()) , volt);
  FR.spin(fwd, 0.7*0.12*(Controller1.Axis3.value()-Controller1.Axis1.value()) , volt);
    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.


    if(Controller1.ButtonR1.pressing()) {
    mogo.spin(vex::directionType::fwd, 80, vex::velocityUnits::pct);
    }
    else if(Controller1.ButtonR2.pressing())
    {
    mogo.spin(vex::directionType::rev, 80, vex::velocityUnits::pct);
    }
    else {
        mogo.stop(vex::brakeType::hold);


        }

    if(Controller1.ButtonL1.pressing()) {
    arm.spin(vex::directionType::fwd, 80, vex::velocityUnits::pct);
    }
    else if(Controller1.ButtonL2.pressing())
    {
    arm.spin(vex::directionType::rev, 80, vex::velocityUnits::pct);
    }
    else {
        arm.stop(vex::brakeType::hold);


        }

    if(Controller1.ButtonX.pressing()) {
    claw.spin(reverse,9, volt);
    }
    else if(Controller1.ButtonB.pressing())
    {
    claw.spin(forward,9, volt);
    }
    else {
        claw.stop(vex::brakeType::hold);


        }


                  
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);
  vexcodeInit();
  inertial1.calibrate();
  // waits for the Inertial Sensor to calibrate
  while (inertial1.isCalibrating()) {
    wait(100, msec);
  }

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
